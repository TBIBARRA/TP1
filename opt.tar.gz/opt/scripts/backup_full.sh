# Mostrar ayuda
function mostrar_ayuda {
    echo "Uso: $0 [origen] [destino]"
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo
    echo "Opciones:"
    echo "  -help     Mostrar esta ayuda"
    exit 0
}

# Verifica si se solicitó ayuda
if [[ "$1" == "-help" || "$1" == "--help" ]]; then
    mostrar_ayuda
fi

# Validar cantidad de argumentos
if [[ $# -ne 2 ]]; then
    echo "Error: Se requieren 2 argumentos."
    mostrar_ayuda
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)

# Validar existencia de origen
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: Directorio de origen '$ORIGEN' no existe."
    exit 1
fi

# Validar existencia de destino
if [[ ! -d "$DESTINO" ]]; then
    echo "Error: Directorio de destino '$DESTINO' no existe."
    exit 1
fi

# Validar que ambos estén montados
if ! mountpoint -q "$ORIGEN"; then
    echo "Advertencia: '$ORIGEN' no es un punto de montaje. Continuando..."
fi

if ! mountpoint -q "$DESTINO"; then
    echo "Error: '$DESTINO' no está montado."
    exit 1
fi

# Construir nombre del archivo de backup
NOMBRE_DIR=$(basename "$ORIGEN")
ARCHIVO="${DESTINO}/${NOMBRE_DIR}_bkp_${FECHA}.tar.gz"

# Ejecutar backup
echo "Generando backup de '$ORIGEN' en '$ARCHIVO'..."
tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE_DIR"

# Confirmación
if [[ $? -eq 0 ]]; then
    echo "Backup exitoso: $ARCHIVO"
else
    echo "Error al realizar el backup"
    exit 1
fi